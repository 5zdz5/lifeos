---
name: lifeos-maintainer
description: LifeOS / 识海 项目的维护与发布工作流。当需要构建、验证或发布 LifeOS 网页版，改动样式层、存储层或数据可视化，跑 Node 与浏览器回归，生成视觉截图与二维码，或排查线上内容一致性问题时使用。涵盖零依赖 CSS 单源构建、IndexedDB 双写灰度、全量字节 hash 校验、视觉回归与一键回滚基线。
---

# LifeOS Maintainer

## Overview

LifeOS 是一个本地优先的静态 PWA：`src/` 目录既是源码也是线上服务目录（本机 3000 端口静态服务映射到公网域名）。**改动 `src/` 即改动线上内容**，因此每次变更都必须走完整验证链，不能只跑 build。

本 Skill 把「改代码 → 构建 → 验证 → 发布 → 留证据」固化为可执行流程，避免踩中历史上真实发生过的坑（版本戳未更新、SW 缓存残留、备份泄漏密钥、URL 参数拼进 fragment、动画中间帧被当成视觉破损）。

## 何时使用

- 修改 `src/css/*.css`、`src/js/storage.js`、`src/js/modules/heatmap.js`、`graph.js` 等核心文件后需要发布
- 新增功能后需要确认 12 导航 / `ENTITY_KEYS` / `version.json` 文件数这些硬断言没被破坏
- 需要重新生成视觉回归截图、二维码或线上新版本链接
- 线上内容与本地不一致、SW 缓存没更新、浏览器控制台报错

## 不变量（改动前先记住，全都有硬断言）

| 不变量 | 值 | 校验位置 |
|---|---|---|
| 首页导航视图数 | 12 | `verify-release.js`、`tests/browser.test.js` |
| 顶层实体 `ENTITY_KEYS` | 6 个 | `src/js/store.js`、`tests/w3.test.js` |
| `version.json` 文件数 | 35 | `tests/w3.test.js` |
| 运行时 CSS | 单一 `css/app.css` | `tests/build.test.js` |
| 发布一致性 | 49 项全文件字节 hash | `verify-release.js` |

**新增功能优先做成既有模块的子视图或顶栏入口**，不要新增导航项或顶层实体，否则会同时打断验证链、备份链与导入链（W2 的 Daily Notes 与全局检索就是这么做的）。

## 标准流程

```bash
cd /workspace/lifeos

# 1. 改源码（样式改 style.css / finesse.css，不要手改 app.css）
npm run build:css          # 只重建 app.css（零依赖确定性合并）

# 2. 全量构建：生成版本戳、SW 清单、standalone、鸿蒙 rawfile
npm run build

# 3. Node 回归（13 套件，浏览器套件条件跳过属正常）
npm test

# 4. 线上全量一致性（src 即线上目录，构建后立即生效）
node verify-release.js

# 5. 浏览器回归（把 version.json 里的 hash 填进 v= 参数）
LIFEOS_TEST_URL="https://alifeosv3nov09.app.workbuddy.host/?sharecode=33O3OVO2Z3&v=<hash>#dashboard" \
  npm run test:browser

# 6. 视觉回归（11 张逐张清单，含 3 张动效静帧）
SHOTS_SET=w3 PREFIX=w3 LIFEOS_TEST_URL="...&v=<hash>#dashboard" \
  node tools/capture-shots.js

# 7. 一键串起 1–6 并刷新二维码
bash .codebuddy/skills/lifeos-maintainer/scripts/release.sh
```

`scripts/release.sh` 是上面流程的可执行封装；**任一环节失败即停**，不会继续发布。

## 失败即停与回滚

出现以下任一情况立刻停止后续步骤：49 项一致性失败、浏览器回归任一失败、控制台报错、逐张视觉比对破损。

- 回滚基线：`.rollback/src-w0`（30 文件）+ `.rollback/w0-files`（14 文件）+ `baseline-w0.sha256`
- 存储层应急：设置页「一键切回旧存储」或 URL 加 `?storage=legacy`（注意用 `URL.searchParams`，不要字符串拼接）
- CSS 应急：把 `index.html` 的两个 stylesheet 引回 `style.css` / `finesse.css`

## 设计约束速记

- 样式只改 `style.css`（基础层）或 `finesse.css`（覆盖层），`app.css` 是生成物
- 跨文件重复选择器是**有意层叠覆盖**，不做规则级破坏性删除（见 ADR-002）
- 动效必须尊重 `prefers-reduced-motion`；统计数字是权威数据，**不做数值缓动**（见 `references/design-system.md`）
- 交错动效统一走 `L.utils.stagger()`，不要各模块各写一套 rAF
- 密钥相关：`SECRET_SETTING_KEYS` 永不进备份/快照，导入不能覆盖本机密钥

## Resources

- `references/design-system.md` — 设计令牌、CSS 双层、动效契约与 reduced-motion 规范
- `references/release-checklist.md` — 发布验证矩阵、二维码生成、已知限制与撤销条件
- `scripts/release.sh` — 一键构建 + 全量验证 + 截图 + 二维码刷新
- 项目决策记录：`docs/ADR-001-*.md` / `ADR-002-*.md` / `ADR-003-*.md`
- 交接检查点：`.ai-memory/handoff.md`

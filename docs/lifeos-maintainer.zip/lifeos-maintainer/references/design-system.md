# LifeOS 设计系统与动效规范

> 供维护时快速对齐「一套色板、一种画风」。细节以源码为准：`src/css/style.css`（基础层）、`src/css/finesse.css`（覆盖层）、`src/js/utils.js`（动效工具）。

## 1. 令牌体系

深浅两套主题通过 `:root` 与 `[data-theme]` 切换，**所有颜色必须走变量**，不允许在组件样式里写死色值。

| 变量 | 用途 |
|---|---|
| `--accent` / `--accent2` | 主强调色（Teal / Clay 体系） |
| `--accent-soft` | 强调色低饱和底（选中态、高亮、柔光） |
| `--on-accent` | 强调色上的文字 |
| `--panel` / `--panel2` | 面板与次级面板 |
| `--border` / `--muted` | 描边与次级文字 |
| `--needs` / `--auto` / `--up` / `--down` | 状态语义色（在等你 / 自动完成 / 增长 / 下降） |
| `--r` / `--r-sm` / `--shadow` | 圆角与阴影 |
| `--fs-1` … `--fs-7` | 字号阶梯 |
| `--ease` | `cubic-bezier(.16, 1, .3, 1)`，所有动效统一缓动 |

> 金融/涨跌场景遵循中国习惯：涨红跌绿。货币默认 `¥`。

## 2. CSS 双层与单一来源

- `style.css` = 基础层（令牌、组件、深浅主题）
- `finesse.css` = 覆盖层（finesse 设计系统、Codex 信任层、窄屏、W2/W3 特性样式）
- `tools/build-css.js` 零依赖确定性合并两者 → `src/css/app.css`（**生成物，禁止手改**）
- `index.html` 只引一份 `app.css`；`build-standalone.js` 内联同一份

**跨文件重复选择器（当前 185 处）是有意的层叠覆盖**，不是冗余。不要做规则级删除：删除会改变视觉或让基础层单独引用时失样式。撤销条件见 `docs/ADR-002-*.md`。

## 3. 动效契约（W3 起）

统一工具 `L.utils`：

| 方法 | 行为 |
|---|---|
| `motionOK()` | `prefers-reduced-motion: reduce` 时返回 false；无 `matchMedia` 时保守返回 true |
| `stagger(nodes, stepMs, varName, cap)` | 写入交错序号（默认 `--motion-i`，可传 `--hm-wi`）与 `--motion-step`；是所有交错动效的**唯一来源**，序号默认封顶 40 |
| `countUp(el, to, ms)` | 数字缓动公共能力；reduce / 无 rAF / 终值 0 时直接落终值。**当前不挂载统计卡片** |

节奏约束：

- 时长 `.12–1.2s`，统一 `var(--ease)`，位移 ≤8px
- 不做弹跳、旋转、斜切、视差、常驻无限闪烁、随机渐变
- 所有入场动画包在 `@media (prefers-reduced-motion: no-preference)` 内
- 必须有配对的 `@media (prefers-reduced-motion: reduce)` 归零块；图谱还要清除 `stroke-dasharray` / `stroke-dashoffset` 残留
- `style.css` 的两个 legacy 无限动画（`.cx2-live` / `.cx2-dot`）在基础层也单独关掉

### 权威数据不做数值动画

统计卡片（`.hs-num`、`.gs b`、`.stat-num` 等）显示的是**真实统计值**。W3 首版曾对它们做 countUp + 交错延迟，逐张比对发现中间帧出现偏小值（107 而非 168）且部分数字完全空白 —— 属「为动而动」误导用户。

规范：统计数字只做**统一无延迟淡入**（`w3-rise`），不做数值缓动、不做交错隐藏；`data-count` 属性保留真值供回归断言使用。

### 数据可视化动效

- 热力图：`U.stagger(.hm-col, 13, '--hm-wi', 60)` 写列序号，CSS 变量**继承**到 `.hy-cell`，用 `calc(var(--hm-wi, 0) * 13ms)` 做按列波浪点亮；今日格子一次性柔光
- 知识图谱：`--g-len` 写入真实边长，`stroke-dasharray/dashoffset` 描边生长；节点/边用 `U.stagger(..., 22)` 交错淡入
- **禁止用 CSS `transform` 动画作用于图谱 `<g>`**，因为节点定位靠 `transform="translate(...)"`，会被覆盖导致节点全部堆到原点

## 4. 微交互一致性（C2）

- 统一 `:focus-visible` 焦点环：按钮、图标按钮、导航项、输入框、检索结果、空态按钮
- `.btn` 统一 `transition`，`:active` 统一 `translateY(1px)`，primary 悬停微亮
- 模态框契约：ESC 关闭、Enter 提交主操作、自动聚焦首个输入；`U.modal({ wide: true })` 用于全局检索等宽内容

## 5. 「六种做坏方式」自查清单

提交视觉改动前逐条过：

1. 是不是引入了新的硬编码色值？（应全部 `var(--...)`）
2. 是不是为了让页面「活起来」而让真实数据短暂显示错误值？
3. 是不是有常驻无限循环 / 旋转 / 弹跳 / 视差？
4. 是不是忘了 `prefers-reduced-motion` 归零？
5. 是不是各模块各写了一套 rAF / matchMedia（应统一走 `L.utils`）？
6. 是不是在 320px 窄屏下溢出、文字截断或按钮重叠？

这些约束已固化在 `tests/w3.test.js`（零硬编码色值、无 rotate/skew/infinite、关键帧齐备、reduce 归零）。

## 6. 视觉回归清单

`SHOTS_SET=w3 PREFIX=w3 node tools/capture-shots.js` 产出 11 张：

深色总览 / 浅色总览 / 笔记 / 图谱 / 日历 / 热力图 / 设置 / 320px 窄屏 / 热力图波浪中间帧 / 图谱描边中间帧 / reduced-motion 静帧。

- **基线截图必须拍稳定态**：heatmap 与 graph 等待 1200ms（波浪最长约 1s），否则中间帧会被误判成「数据缺失」
- 动效静帧用短等待（150ms / 190ms）呈现中间过程
- 每张都要人工比对：无空白、无截断、无重叠、数字完整、控制台零报错
- 设置页需额外滚动到 `#s-storage-mode` 补一张存储引擎区块截图

# LifeOS 发布清单与验证矩阵

> 线上域名 `https://alifeosv3nov09.app.workbuddy.host/?sharecode=33O3OVO2Z3` 映射到本机 3000 端口静态服务（`--directory /workspace/lifeos/src`）。**`src/` 就是线上目录**，改完即生效；`v=<hash>` 只用于 bust 浏览器/SW 缓存，不是部署开关。`sharecode` 是网关凭据，应用本身无鉴权。

## 1. 验证矩阵（S3 四条硬判据）

| 判据 | 命令 | 期望 |
|---|---|---|
| ① 全绿 | `npm test` | 13 个 Node 套件全过（浏览器套件条件跳过属正常） |
| ② 零控制台报错 | `npm run test:browser` | 91/91，页面零脚本报错 |
| ③ 逐张视觉回归 | `SHOTS_SET=w3 node tools/capture-shots.js` | 11 张人工比对零破损 |
| ④ 新功能各有断言 | `grep -c "ok(" tests/*.test.js` | 每功能 ≥3 条，测试文件清晰可查 |
| ⑤ 发布一致性 | `node verify-release.js` | 49/49，线上内容与本地构建**字节级**完全一致 |

**失败即停**：①–⑤ 任一失败立即停止后续步骤，回滚到该 Wave 起点。

## 2. 构建与版本机制

`npm run build` = `node tools/build-css.js && node build-standalone.js`，一次完成：

1. 合并 `style.css + finesse.css` → `src/css/app.css`
2. 依据 33 个源码文件（含 `sw.js` 逻辑）算出 8 位版本 hash，写 `version.json` / `js/version.js`
3. 更新 `sw.js` 的 `CACHE` 名与 `ASSETS` 清单（当前 36 项）
4. 生成 `src/standalone.html` 与 `dist/lifeos.html`（约 377 KB）
5. 同步 36 个文件到鸿蒙 `entry/src/main/resources/rawfile/lifeos/`

`version.json` 记录 35 个文件的 hash 前缀；`verify-release.js` 用 `arrayBuffer()` 逐文件比对（早期用 `text()` 导致 PNG 误报，已修）。

## 3. 二维码与新链接

二维码指向带新版本戳的完整 URL，生成后覆盖 `docs/lifeos-open-qr.png`：

```python
import qrcode
url = "https://alifeosv3nov09.app.workbuddy.host/?sharecode=33O3OVO2Z3&v=<hash>#dashboard"
img = qrcode.make(url)
img.save("docs/lifeos-open-qr.png")
```

> 环境里 Python `qrcode` 可用（无 `__version__` 属性属正常）；没有 `qrencode` 命令。
> 旧版本链接保留作为对照，不要主动改动 `sharecode` 网关。

## 4. 桌面端与鸿蒙边界（只做静态验证，如实列为已知限制）

- `node --check main.js preload.js agent-core.js mindsea-service.cjs`（四个主进程文件语法）
- 鸿蒙两份 `build-profile.json5` 与 `module.json5` 用 Python `json5` 解析做语法检查（环境里 `import json5` 可用）
- **Electron GUI 与 Harmony HAP 未在沙箱内图形化构建/验证**，不得在交付物里声称已验证
- 网页版的文件读写、终端命令、JS 执行均为**隔离演示**（iframe + Worker），不会碰本机文件；UI 上必须保留诚实标注

## 5. 密钥与数据安全边界

- `SECRET_SETTING_KEYS = ['aiKey', 'aiBaseUrl']`：导出备份、快照、导入、恢复一律脱敏
- 外部导入/恢复**不能覆盖**本机密钥；旧快照会被 `sanitizeStoredSnapshots` 清洗
- 设置页提供「仅本次会话保存密钥」（`sessionStorage`），默认仍可能明文存 localStorage —— 如实告知用户
- 存储双写灰度三态 `legacy` / `dual` / `idb`：`localStorage` 始终是同步权威且永不删除，IDB 只是异步冗余镜像，一键回滚零丢数据

## 6. 已知限制（交付时必须如实说明）

- 应用本身无鉴权，依赖网关 `sharecode`
- 原生 `input[type=date]` 仍按浏览器语言显示（中文实时回显已消除歧义，但未替换控件）
- `U.countUp` 为公共能力，当前未挂载业务调用（有意，见 design-system.md）
- CSS 跨文件重复选择器 185 处按 ADR-002 结论保留
- `.md` 全库导出为逐个下载（零依赖取舍，无打包）
- 全局检索的识海侧依赖 `L.mindsea.exportData()` 异步快照，首次打开可能延迟一帧
- Electron / 鸿蒙 HAP 未图形验证；网页版文件/命令执行为隔离演示

## 7. 回滚

- 回滚基线：`.rollback/src-w0`、`/workspace/lifeos/.rollback/w0-files`、`baseline-w0.sha256`（45 行）
- 恢复后必须重跑 `npm run build` → `node verify-release.js` → 确认旧链接可用
- 存储层应急：设置页「一键切回旧存储」或 URL `?storage=legacy`
- CSS 应急：`index.html` 引回两份源 CSS
- URL 参数构造一律用 `new URL(...).searchParams`，**禁止字符串拼接**（带 `#dashboard` 时会把参数拼进 fragment，历史上导致 K 段假失败）

## 8. 决策记录索引

- `docs/ADR-001-storage-adapter.md` — 统一存储适配层与同步接口
- `docs/ADR-002-css-single-source.md` — 零依赖 CSS 单源构建与规则级收敛结论
- `docs/ADR-003-dual-write-rollback.md` — 双写灰度回滚与密钥边界
- `.ai-memory/handoff.md` — 每个 Wave 的检查点与证据

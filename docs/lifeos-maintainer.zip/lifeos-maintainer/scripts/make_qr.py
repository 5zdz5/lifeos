#!/usr/bin/env python3
"""生成 LifeOS 在线预览二维码卡片（带版本标题，避免中文字形缺失）。

用法：
    python3 make_qr.py <url> [version] [output.png]

依赖：qrcode、Pillow（环境内已可用）。
"""
import sys
from urllib.parse import urlparse, parse_qs

import qrcode
from PIL import Image, ImageDraw, ImageFont

FONTS = '/usr/share/fonts/truetype/dejavu/'
BG = (245, 250, 249)
HEAD = (238, 246, 244)
INK = (13, 40, 38)
ACCENT = (23, 108, 107)
MUTED = (90, 110, 108)


def font(name, size):
    try:
        return ImageFont.truetype(FONTS + name, size)
    except OSError:
        return ImageFont.load_default()


def main():
    if len(sys.argv) < 2:
        print('Usage: make_qr.py <url> [version] [output.png]')
        sys.exit(1)
    url = sys.argv[1]
    version = sys.argv[2] if len(sys.argv) > 2 else ''
    if not version:
        q = parse_qs(urlparse(url).query)
        version = (q.get('v') or [''])[0]
    out = sys.argv[3] if len(sys.argv) > 3 else 'docs/lifeos-open-qr.png'

    W, H = 387, 495
    canvas = Image.new('RGB', (W, H), BG)
    d = ImageDraw.Draw(canvas)
    d.rectangle([0, 0, W, 100], fill=HEAD)
    d.text((20, 16), 'LifeOS  /  Online Preview', font=font('DejaVuSans-Bold.ttf', 21), fill=INK)
    d.text((20, 50), version or 'current build', font=font('DejaVuSans-Bold.ttf', 13), fill=ACCENT)
    d.text((20, 70), 'Scan to open  -  keep the sharecode parameter',
           font=font('DejaVuSans.ttf', 11), fill=MUTED)

    qr = qrcode.make(url).convert('RGB').resize((340, 340), Image.NEAREST)
    canvas.paste(qr, ((W - 340) // 2, 118))
    d.text((20, 468), 'lifeos  .  workbuddy preview',
           font=font('DejaVuSans.ttf', 11), fill=MUTED)
    canvas.save(out)
    print('   QR ->', out, '|', version)


if __name__ == '__main__':
    main()

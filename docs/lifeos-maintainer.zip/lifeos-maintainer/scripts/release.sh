#!/usr/bin/env bash
# =============================================================================
# LifeOS 一键发布：构建 → Node 回归 → 线上一致性 → 浏览器回归 → 视觉回归 → 二维码
#
#   bash .codebuddy/skills/lifeos-maintainer/scripts/release.sh
#
# 可覆盖：LIFEOS_ROOT / LIFEOS_BASE_URL / LIFEOS_SHOT_PREFIX / CHROME_PATH
# 任一环节失败即停（set -e），不会继续发布。
# =============================================================================
set -euo pipefail

ROOT="${LIFEOS_ROOT:-/workspace/lifeos}"
cd "$ROOT"

BASE_URL="${LIFEOS_BASE_URL:-https://alifeosv3nov09.app.workbuddy.host/?sharecode=33O3OVO2Z3}"
PREFIX="${LIFEOS_SHOT_PREFIX:-w3}"

echo "▶ 1/7 构建（CSS 单源合并 + 版本戳 + SW + standalone + 鸿蒙 rawfile）"
npm run build

echo "▶ 2/7 Node 回归（13 套件）"
npm test

echo "▶ 3/7 线上全量字节一致性（49 项）"
node verify-release.js

HASH="$(node -e "process.stdout.write(require('./src/version.json').version)")"
SHORT="${HASH#v}"   # version.json 是 vf94fa32f；URL 参数要 f94fa32f
TEST_URL="${BASE_URL}&v=${SHORT}#dashboard"
echo "   版本戳：${HASH}（URL 参数 v=${SHORT}）"

echo "▶ 4/7 浏览器回归（91 条 + 零控制台报错）"
LIFEOS_TEST_URL="$TEST_URL" npm run test:browser

echo "▶ 5/7 逐张视觉回归（11 张）"
SHOTS_SET=w3 PREFIX="$PREFIX" LIFEOS_TEST_URL="$TEST_URL" node tools/capture-shots.js

echo "▶ 6/7 刷新二维码"
python3 .codebuddy/skills/lifeos-maintainer/scripts/make_qr.py \
  "$TEST_URL" "$HASH" docs/lifeos-open-qr.png

echo "▶ 7/7 汇总"
KB="$(( $(wc -c < dist/lifeos.html) / 1024 ))"
echo "────────────────────────────────────────────"
echo " 版本      : ${HASH}"
echo " standalone: dist/lifeos.html (${KB} KB)"
echo " 新链接    : ${TEST_URL}"
echo " 二维码    : docs/lifeos-open-qr.png"
echo " 截图      : docs/${PREFIX}-*.png (11 张)"
echo " 证据      : .ai-memory/handoff.md"
echo "────────────────────────────────────────────"
echo "✅ 发布完成。请人工复核 11 张截图后再对外给链接。"
